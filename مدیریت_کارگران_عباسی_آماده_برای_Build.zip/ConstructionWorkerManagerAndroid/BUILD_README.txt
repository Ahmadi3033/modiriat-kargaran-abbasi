این نسخه برای ساخت آسان APK آماده شده است.
روش پیشنهادی: پروژه را در GitHub آپلود کنید؛ فایل .github/workflows/build-apk.yml خودش APK را می‌سازد.
بعد از آپلود، از Actions > Build APK > Run workflow استفاده کنید و فایل را از Artifacts دانلود کنید.
